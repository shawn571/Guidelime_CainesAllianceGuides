Guidelime.registerGuide([[
[GA Alliance][N46-47The Hinterlands][NX47-48Tanaris]
Talk to Fraggar Thundermantle to accept [QA2877 Skulk Rock Clean-Up].
Talk to Agnar Beastamer to turn in [QT3843 The Newest Member of the Family] and accept [QA4297 Food for Baby].
Talk to Rhapsody Shindigger to turn in [QT1452 Rhapsody's Kalimdor Kocktail] and accept [QA1469 Rhapsody's Tale].
Pick up Wildkin Feathers for [QC3661 Favored of Elune?][O] while doing the next steps.
Pick up Sack of Rye for [QC49,3 Sweet Amber].
Kill Silvermane Stalkers for [QC4297 Food for Baby][O] while doing the next steps.
Kill oozes for [QC2877 Skulk Rock Clean-up].
When OOX-09/HL Distress Beacon drops use it in your bag to accept [QA485 Find OOX-09/HL!].
Click Homing Robot OOX-09/HL to turn in [QT485 Find OOX-09/HL!] and accept [QA836 Rescue OOX-09/HL!].
Escort the robot to safety to complete [QC836 Rescue OOX-09/HL!].
Reach level [XP47].
Pick up Pupellyverbos Port for [QC580 Whiskey Slim's Lost Grog][OC] while doing the next step.
Take a picture of Gammerita with the Super Snapper FX in your bag for [QC2944 The Super Snapper FX].
Finish up [QC580 Whiskey Slim's Lost Grog].
Click Cortello's Treasure for [QT626 Cortello's Riddle].
Finish up [QC4297 Food for Baby].
Finish up [QC3661 Favored of Elune?].
Talk to Fraggar Thundermantle to turn in [QT2877 Skulk Rock Clean-up].
Talk to Agnar Beastamer to turn in [QT4297 Food for Baby] and accept [QA4298 Becoming a Parent]. Turn in [QT4298 Becoming a Parent].
Hearth to Gadgetzan[H].
]], 'Caines Alliance Guides')