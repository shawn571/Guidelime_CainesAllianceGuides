Guidelime.registerGuide([[
[GA Alliance][N44-45Tanaris][NX45-46Feralas]
Talk to Krinkle Goodsteel to turn in [QT4450 Ledger from Tanaris].
Talk to Chief Engineer Bilgewhizzle to accept [QA1691 More Wastewander Justice].
Talk to Curgle Cranklehop to accept [QA3022 Handle With Care].
[G51.84,27.02,1Tanaris]Click the Wanted Poster to accept [QA2781 WANTED: Caliph Scorpidsting]
Click Wanted Poster to accept [QA2875 WANTED: Andre Firebeard].
Talk to Shreev to accept [QA1189 Safety First].
[G51.3,20.8Tanaris][G77.8,77.3,2Thousand Needles]Talk to Kravel Koalbeard to turn in [QT1119 Zanzil's Mixture and a Fool's Stout] and accept [QA1120 Get the Gnomes Drunk].
Talk to Gnome Pit Boss to turn in [QT1120 Get the Gnomes Drunk].
Talk to Fizzle Brassbolts to turn in [QT1137 News for Fizzle].
OPTIONAL ZUL'FARRAK QUEST - Talk to Wizzle Brassbolts to pick up [QA2770 Gahz'rilla].
Talk to Pozzik to accept [QA1190 Keeping Pace].
Talk to Razzeric to turn in [QT1189 Safety First].
Talk to Zamek to accept and turn in [QA1191 Zamek's Distraction][QT1191 Zamek's Distraction]. Mark this step complete.
Click Rizzle's Unguarded Plans when he leaves to turn in [QT1190 Keeping Pace] and accept [QA1194 Rizzle's Schematics].
Talk to Pozzik to turn in [QT1194 Rizzle's Schematics].
Kill Roc's for [QC1452,1 Rhapsody's Kalimdor Kocktail][O] while doing the next steps.
Talk to Yeh'kinya to turn in [QT3520 Screecher Spirits].
OPTIONAL ZUL'FARRAK QUEST - Accept [QA3527 The Prophecy of Mosh'aru].
Talk to Haughty Modiste to accept [QA8365 Pirate Hats Ahoy!].
Talk to Security Chief Bilgewhizzle to accept [QA8366 Southsea Shakedown].
Talk to Stoley to accept [QA2873 Stoley's Shipment].
Kill Caliph Scorpidsting for [QC2781 WANTED: Caliph Scorpidsting].
Click Sack of Corn for [QC49,2 Sweet Amber].
Kill Wastewander enemies for [QC1691 More Wastewander Justice].
[G67.98,41.18Tanaris][G75,46Tanaris]Kill Southsea enemies for [QC8366 Southsea Shakedown][O] and [QC8365 Pirate Hats Ahoy!][O] while doing the next steps.
Kill Andre Firebeard for [QC2875 WANTED: Andre Firebeard].
Click Stolen Cargo for [QC2873 Stoley's Shipment].
Click Pirate's Footlocker to get Ship Schedule and use it in your bag to accept [QA2876 Ship Schedules][G75,46Tanaris]
Finish up [QC8366 Southsea Shakedown] and [QC8365 Pirate Hats Ahoy!].
Reach level [XP45].
Talk to Security Chief Bilgewhizzle to turn in [QT2875 WANTED: Andre Firebeard], [QT2876 Ship Schedules], and [QT8366 Southsea Shakedown].
Talk to Stoley to turn in [QT2873 Stoley's Shipment].
Talk to Haughty Modiste to turn in [QT8365 Pirate Hats Ahoy!].
Finish up [QC1452,1 Rhapsody's Kalimdor Kocktail].[G49,36Tanaris]
Talk to Chief Engineer Bilgewhizzle to turn in [QT1691 More Wastewander Justice] and [QT2781 WANTED: Caliph Scorpidsting].
Talk to Innkeeper Fizzgrimble to make this inn your home.[S][G52.5,27.9,2Tanaris]
Fly to [F Feathermoon].
]], 'Caines Alliance Guides')