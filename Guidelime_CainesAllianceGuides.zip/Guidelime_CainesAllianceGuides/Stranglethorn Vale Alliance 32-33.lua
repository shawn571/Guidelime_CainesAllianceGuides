Guidelime.registerGuide([[
[GA Alliance][N32-33Stranglethorn Vale][NX33-34Dustwallow Marsh and Thousand Needles]
OPTIONAL ELITE - Talk to Sven Yorgen to accept [QA55 Morbent Fel].
Kill Morbent Fel for [QC55 Morbent Fel].
Click Eliza's Grave Dirt to accept and turn in [QA254 Digging Through the Dirt][QT254 Digging Through the Dirt].
Kill Eliza for [QC253 Bride of the Embalmer].
Kill Mor'Ladim for [QC228 Mor'Ladim].
Talk to Sven Yorgen to turn in [QT55 Morbent Fel].
[G44.5,87.7,3Duskwood][G38.0,5.0,3Stranglethorn Vale]Head to Stranglethorn Vale and talk to Private Thorsen to accept [QA215 Jungle Secrets].
[G38.2,4.0,1Stranglethorn Vale]Talk to Nizzle to get the flight point.[P]
Talk to Sergeant Yohwa to accept [QA203 The Second Rebellion] and [QA204 Bad Medicine].
Talk to Lieutenant Doren to turn in [QT215 Jungle Secrets] and accept [QA200 Bookie Herod].
Talk to Corporal Kaleb to accept [QA210 Krazek's Cookery].
While doing the next steps, kill River Crocolisks for [QC575 Supply and Demand][O].
[G35.7,10.5,3Stranglethorn Vale]Go to Nesingwary's camp for [QC201 Investigate the Camp].
Talk to Barnil Stonepot to accept [QA583 Welcome to the Jungle].
Talk to Hemet Nesingwary to turn in [QT583 Welcome to the Jungle] and accept [QA194 Raptor Mastery].
Talk to Ajeck Rouack to accept [QA185 Tiger Mastery].
Talk to Sir S. J. Erlgadin to accept [QA190 Panther Mastery].
Kill Young Stranglethorn Tigers for [QC185 Tiger Mastery].
Talk to Ajeck Rouack to turn in [QT185 Tiger Mastery] and accept [QA186 Tiger Mastery].
Kill Young Panthers for [QC190 Panther Mastery].[G41,11Stranglethorn Vale]
Finish up [QC575 Supply and Demand].[G40,12Stranglethorn Vale].
Click Kurzen Supplies for [QC204,2 Bad Medicine].[G44.5,9.8,2Stranglethorn Vale][L44.1,9.6Stranglethorn Vale]
Kill Kurzen Medicine Men for [QC204,1 Bad Medicine] and Kurzen Jungle Fighters for [QC203 The Second Rebellion].
Click Bookie Herod's Records to turn in [QT200 Bookie Herod].
While doing the next steps kill Stranglethorn Tigers for [QC186 Tiger Mastery][O].
Talk to Sergeant Yohwa to turn in [QT203 The Second Rebellion] and [QT204 Bad Medicine].
Talk to Sir S. J. Erlgadin to turn in [QT190 Panther Mastery] and accept [QA191 Panther Mastery].
Kill Stranglethorn Tigers and Panthers for [QC186 Tiger Mastery] and [QC191 Panther Mastery].[G29,11Stranglethorn Vale]
Kill Stranglethorn Raptors for [QC194 Raptor Mastery].[G25,16Stranglethorn Vale]
Talk to Sir S. J. Elgadin to turn in [QT191 Panther Mastery].
Talk to Ajeck Rouack to turn in [QT186 Tiger Mastery].
Talk to Hemet Nesingwary to turn in [QT194 Raptor Mastery].
Reach level [XP33].
#Put a point in Predatory Strikes.[A Druid]
#Put a point in Ferocity.[A Hunter]
#Put a point in Shadow Weaving.[A Priest]
#Put a point in Improved Cone of Cold.[A Mage]
#Put a point in Two-Handed Weapon Specialization.[A Paladin]
#Put a point in Dual Wield Specialization.[A Rogue]
#Put a point in Siphon Life.[A Warlock]
#Put a point in Axe Specialization.[A Warrior]
Hearth to Ironforge.
Fly to [F Menethil Harbor].
Talk to Mikhail to accept [QA1249 The Missing Diplomat].
Beat Tapoke "Slim" Jahn for [QC1249 The Missing Diplomat].
Talk to Mikhail to turn in [QT1249 The Missing Diplomat].
Talk to Tapoke "Slim" Jahn to accept [QA1250 The Missing Diplomat].
Talk to Mikhail to turn in [QT1250 The Missing Diplomat] and accept [QA1264 The Missing Diplomat].
Talk to Kersok Prond and buy 3 Soothing Spices for a later quest.[G10.4,60.6,2Wetlands]
Take the boat to Theramore.[G5.0,63.5,2Wetlands]
]], 'Caines Alliance Guides')