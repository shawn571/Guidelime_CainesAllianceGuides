Guidelime.registerGuide([[
[GA Alliance][N29-29Ashenvale][NX29-30Duskwood]
Talk to Shindrell Swiftfire to accept [QA4581 Kayneth Stillwind].
Talk to Sentinel Melyria Frostshadow to accept [QA1022 The Howling Vale].
Talk to Illiyana to accept [QA1021 Vile Satyr! Dryads in Danger!].
Go up the path [G61.0,48.4,3Ashenvale][G53.6,32.8,3Ashenvale]to get the Tome of Mel'Thandris for [G50.5,39.1,2Ashenvale][QC1022 The Howling Vale].
Go to Anilia to turn in [G63.9,43.8,3Ashenvale][G78.3,44.8,2Ashenvale][QT1021 Vile Satyr! Dryads in Danger!] and accept [QA1031 The Branch of Cenarius].
Kill Geltharis to complete [QC1031 The Branch of Cenarius].
Talk to Kayneth Stillwind to turn in [QT4581 Kayneth Stillwind].
Talk to Kayneth Stillwind to accept [QA9519 The Lost Chalice] and [QA1011 Forsaken Diseases]
[G85.0,43.4,1Ashenvale]Talk to Suralais Farwind to get the Forest Song flight point [P]
Talk to Sentinel Melyria to accept [QA9521 Report from the Northern Front] and [QA9518 Agents of Destruction]
Talk to Sentinel Melyria Frostshadow to accept [QA1022 The Howling Vale].
Talk to Vindicator Vedaar to accept [QA9516 Destroy the Legion].
Talk to Illiyana to accept [QA1021 Vile Satyr! Dryads in Danger!].
Talk to Architect Nemos to accept [QA9517 A Shameful Waste]
Talk to Gnarl to accept [QA9526 Reclaiming Felfire Hill]
Go to Anilia to turn in [G63.9,43.8,3Ashenvale][G78.3,44.8,2Ashenvale][QT1021 Vile Satyr! Dryads in Danger!] and accept [QA1031 The Branch of Cenarius].
Kill Geltharis to complete [QC1031 The Branch of Cenarius].
Get Satyrnaar Fel Wood for [QC9517,2 A Shameful Waste].
Get the Chalice of Elune for [QC9519 The Lost Chalice]
Get Warsong Lumber for [QC9517,1 A Shameful Waste][O] and kill Warsong Shredders, Horde Deforesters, and Horde Scouts for [QC9518,2 Agents of Destruction][O][QC9518,3 Agents of Destruction][O][QC9518,4 Agents of Destruction][O] while doing the next step
Kill Overseer Gorthak for [QC9518,1 Agents of Destruction]
Finish up [QC9517,1 A Shamefule Waste] and [QC9518 Agents of Destruction].
Kill Mannoroc Lashers, Roaming Felguards and Searing Infernals for [QC9516 Destroy the Legion] and click Fertile Dirt Mounds for [QC9526 Reclaiming Felfire Hill]
When Diabolical Plans drop, accept [QA9520 Diabolical Plans] in your bags
Get a Bottle of Disease for [QC1011 Forsaken Diseases]
Talk to Sentinel Farsong to turn in [QT9521 Report from the Northern Front]
Click the Tome of Mel'Thandris for [QC1022 The Howling Vale]
Talk to Kayneth Stillwind to turn in [QT1011 Forsaken Diseases] and accept [QA1012 Insane Druids]. Turn in [QT9519 The Lost Chalice]
Talk to Sentinel Luciel Starwhisper to turn in [QT9518 Agents of Destruction].
Talk to Sentinel Melyria Frostshadow to turn in [QT1022 The Howling Vale] and accept [QA1037 Velinde Starsong].
Talk to Vindicator Vedaar to turn in [QT9516 Destroy the Legion] and [QT9520 Diabolical Plans]. Accept [QA9522 Never Again!]
Talk to Illiyana to turn in [QT1031 The Branch of Cenarius]. Accept [QA1032 Satyr Slaying].
Talk to Gnarl to turn in [QT9517 A Shameful Waste] and [QT9526 Reclaiming Felfire Hill]
Kill satyrs for [QC1032 Satyr Slaying]
Talk to Illiyana to turn in [QT1032 Satyr Slaying]
Head inside the cave here.[G76,75Ashenvale]
Kill Taneel Darkwood for [QC1012,1 Insane Druids]
Kill Mavoris Cloudsbreak for [QC1012,3 Insane Druids]
Kill Uthil Mooncall for [QC1012,2 Insane Druids]
Kill Diathorus the Seeker for [QC9522,2 Never Again!]
Kill Gorgannon for [QC9522,1 Never Again!]
Talk to Kayneth Stillwind to turn in [QT1012 Insane Druids]
Talk to Vindicator Vedaar to turn in [QT9522 Never Again!]
Go to Azshara and talk to Jarrodenus to get the flight point.[P][G95.4,48.5,3Ashenvale][G11.9,77.58,1Azshara]
Fly to [F Astranaar].
Talk to Sentinel Melyria Frostshadow to turn in [QT1022 The Howling Vale] and accept [QA1037 Velinde Starsong].
Talk to Illiyana to turn in [QT1031 The Branch of Cenarius].
Fly to [F Darkshore][A Shaman]
[G30.74,41.00Darkshore] Take the boat to Azuremyst Isle [A Shaman]
Talk to Sulaa to accept [QA9500 Call of Water][A Shaman]
Talk to Farseer Nobundo to turn in [QT9500 Call of Water] and accept [QA9501 Call of Water][A Shaman]
Fly to [F Bloodmyst Isle][A Shaman]
Talk to Aqueous to turn in [QT9501 Call of Water] and accept [QA9503 Call of Water][A Shaman]
Kill Fouled Water Spirits and loot them for [QC9503 Call of Water][A Shaman]
Talk to Aqueous to turn in [QT9503 Call of Water] and accept [QA9504 Call of Water][A Shaman]
Fly to [F The Exodar][A Shaman]
[G20.41,54.17,1 Azuremyst Isle] Take the boat to Auberdine[A Shaman]
Fly to [F Astranaar].[A Shaman]
Click the fountain to complete [QC9504 Call of Water][A Shaman]
Fly to [F Auberdine].[A Shaman]
[G30.74,41.00Darkshore] Take the boat to Azuremyst Isle [A Shaman]
Fly to [F Bloodmyst Isle][A Shaman]
Talk to Aqueous to turn in [QT9504 Call of Water] and accept [QA9508 Call of Water][A Shaman]
[G25,41Bloodmyst Isle]Go to the camp and use the Skin of Purest Water in your bag to summon Tel'athion. Kill him for [QC9508 Call of Water][A Shaman]
Talk to Aqueous to turn in [QT9508 Call of Water] and accept [QA9509 Call of Water].[A Shaman]
Fly to [F The Exodar][A Shaman]
Talk to Farseer Nobundo to turn in [QT9509 Call of Water][A Shaman]
Talk to Sulaa to accept [QA9551 Call of Air][A Shaman]
Talk to Farseer Nobundo to turn in [QT9551 Call of Air] and accept [QA9552 Call of Air][A Shaman]
Talk to Velaada to turn in [QT9552 Call of Air] and accept [QA9553 Call of Air][A Shaman]
Talk to Susurrus to turn in [QT9553 Call of Air] and accept [QA9554 Call of Air][A Shaman]
Talk to Farseer Nobundo to turn in [QT9554 Call of Air][A Shaman]
[G20.41,54.17,1 Azuremyst Isle] Take the boat to Auberdine[A Shaman]
Fly to [F Rut'theran Village].
Go into Darnassus and talk to Thyn'tel Bladeweaver to turn in [QT1037 Velinde Starsong] and accept [QA1038 Velinde's Effects].
Talk to Mathiel to accept [QA2925 Klockmort's Essentials].
Talk to Ilyenia Moonfire to train Bows.[A Dwarf,Hunter][G57.6,46.7,2Darnassus]
Click Velinde's Locker to complete [QC1038 Velinde's Effects].
Talk to Thyn'tel Bladeweaver to turn in [QT1038 Velinde's Effects] and accept [QA1039 The Barrens Port].
Talk to Innkeeper Saelienne to make this inn your home.[G67.4,15.6,2Darnassus].[A Mage]
Teleport to Ironforge.[A Mage]
Fly to [F Menethil Harbor].[A Mage]
Hearth to Menethil Harbor.[H][A Druid,Hunter,Rogue,Priest,Warlock,Warrior,Paladin]
Take the boat to Theramore.[G5.0,63.5,3Wetlands].
Talk to Baldruc to get the flight point.[P][G67.5,51.3,2Dustwallow Marsh].
Go to the Barrens to die and resurrect at the spirit healer.[G64.0,39.4,3Dustwallow Marsh][G59.4,13.0,3Dustwallow Marsh][G54.2,12.3,3Dustwallow Marsh][G54.8,8.0,3Dustwallow Marsh][G64.2,57.1,3The Barrens]
Talk to Bragok to get the flight point.[P][G63.1,37.2,2The Barrens]
Talk to Wharfmaster Dizzywig to turn in [QT1039 The Barrens Port] and accept [QA1040 Passage to Booty Bay].
Talk to Takar the Seer to turn in [QT1716 Devourer of Souls] and accept [QA1738 Heartswood].[A Warlock]
Fly to [F Astranaar].[A Warlock]
Loot the Heartswood for [QC1738 Heartswood].[A Warlock][G31.5,31.4,3Ashenvale]
Fly to [F Ratchet].[A Warlock]
Take the boat to Booty Bay.[G63.7,38.6,3The Barrens]
Talk to Caravaneer Ruzzgot to turn in [QT1040 Passage to Booty Bay] and accept [QA1041 The Caravan Road].
Talk to Drizzlik to accept [QA575 Supply and Demand].
Talk to Krazek to accept [QA201 Investigate the Camp].
Talk to Gyll to get the flight point.[P][G27.5,77.8,2Stranglethorn Vale]
Fly to [F Darkshire].
]], 'Caines Alliance Guides')