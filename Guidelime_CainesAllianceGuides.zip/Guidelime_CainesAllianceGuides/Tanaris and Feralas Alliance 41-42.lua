Guidelime.registerGuide([[
[GA Alliance][N41-42 Tanaris and Feralas][NX42-43 Badlands]
Talk to Chief Engineer Bilgewhizzle to pick up [QA1690 Wastewander Justice].
Talk to Spigot Operator Luglunket to accept [QA1707 Water Pouch Bounty].
Talk to Tran'rek to turn in [QT2864 Tran'rek].
[G51.3,20.8,3Tanaris][G77.8,77.3,2Thousand Needles]Talk to Kravel Koalbeard to turn in [QT1117 Rumors for Kravel] and pick up [QA1118 Back to Booty Bay].
Talk to Fizzle Brassbolts to accept [QA1106 Martek the Exiled].
Talk to Razzeric to turn in [QT1187 Razzeric's Tweaking] and accept [QA1188 Safety First].
[G75.5,96.9,3Thousand Needles][G60,24Tanaris][G67.1,24.0,2Tanaris]Talk to Stoley to turn in [QT2872 Stoley's Debt].
Talk to Yeh'kinya to accept [QA3520 Screecher Spirits].
Kill Wastewander enemies for [QC1690 Wastewander Justice] and [QC1707 Water Pouch Bounty].[G64,30Tanaris][L60,24Tanaris]
Talk to Shreev to turn in [QT1188 Safety First].
Talk to Chief Engineer Bilgewhizzle to turn in [QT1690 Wastewander Justice].
Talk to Spigot Operator Luglunket to turn in [QT1707 Water Pouch Bounty].
Talk to Senior Surveyor Fizzledowser to accept [QA992 Gadgetzan Water Survey].
Use Untapped Dowsing Widget to complete [QC992 Gadgetzan Water Survey] and run away from the enemies that attack.[G39,29,3Tanaris]
Talk to Senior Surveyor Fizzledowser to turn in [QT992 Gadgetzan Water Survey].
Fly to [F Thalanaar].
Kill screechers and use Yeh'kinya's Bramble in your bag on their corpses for [QC3520 Screecher Spirits][G57,60Feralas]. Talk to the spirits once they appear to get credit.
Take the boat to Feathermoon Stronghold.[G43.3,42.7,3Feralas]
Talk to Fyldren Moonfeather to get the flight point.[P][G30.2,43.2,2Feralas]
Talk to Shandris Feathermoon to accept [QA2866 The Ruins of Solarsal].
Click the Solarsal Gazebo to turn in [QT2866 The Ruins of Solarsal] and accept [QA2867 Return to Feathermoon Stronghold].
Talk to Shandris Feathermoon to turn in [QT2867 Return to Feathermoon Stronghold] and accept [QA3130 Against the Hatecrest].
Talk to Latronicus Moonspear to turn in [QT3130 Against the Hatecrest] and accept [QA2869 Against the Hatecrest] and [QA4124 The Missing Courier].
Kill Hatescale naga for [QC2869 Against the Hatecrest].
Reach level [XP42].
Talk to Latronicus Moonspear to turn in [QT2869 Against the Hatecrest].
Talk to Ginro Hearthkindle to turn in [QT4124 The Missing Courier].
Hearth to Booty Bay[H].
Talk to Crank Fizzlebub to turn in [QT1118 Back to Booty Bay].
Fly to [F Sentinel Hill].
Talk to Grimbooze Thunderbrew to accept [QA48 Sweet Amber].
Fly to [F Stormwind].
Go to the auction house and buy a Frost Oil, a Gyrochronatom, and a Patterned Bronze Bracers for a future quest in Badlands.
Talk to Brohann Caskbelly to turn in [QT1448 In Search of the Temple] and accept [QA1449 To the Hinterlands].
Fly to [F Ironforge].
Talk to Prospector Stormpike and accept [QA707 Ironband Wants You!].
Fly to [F Thelsamar].
Talk to Prospector Ironband to turn in [QT707 Ironband Wants You!] and accept [QA738 Find Agmond].
Go to Badlands.[G47.4,82.5Loch Modan]
]], 'Caines Alliance Guides')