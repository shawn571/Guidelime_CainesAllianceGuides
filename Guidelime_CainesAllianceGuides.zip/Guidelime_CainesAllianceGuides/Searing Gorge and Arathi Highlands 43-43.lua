Guidelime.registerGuide([[
[GA Alliance][N43-43Searing Gorge and Arathi Highlands][NX43-44The Hinterlands and Stranglethorn Vale]
Click Wooden Outhouse to accept [QA4449 Caught!]
Kill Dark Iron Geologists for [QC4449 Caught!].[G63.77,63.81Searing Gorge]
Click Wooden Outhouse to turn in [QT4449 Caught!] and accept [QA4450 Ledger from Tanaris].
Get Goodsteel Ledger on the ground next to the outhouse for [QC4450,1 Ledger from Tanaris].
Talk to Dorius Stonetender to accept [QA3367 Suntara Stones].
Kill Glassweb Spiders for [QC4450,2 Ledger from Tanaris][O] while doing the next steps.
Finish escorting Dorius Stonetender for [QC3367 Suntara Stones].
Click Singed Letter to turn in [QT3367 Suntara Stones] and accept [QA3368 Suntara Stones].
Finish killing Glassweb Spiders for [QC4450,2 Ledger from Tanaris].
Talk to Kalaran Windblade to accept [QA3441 Divine Retribution].
Talk to Kalaran Windblade and progress through his dialogue to complete [QC3441 Divine Retribution].
Talk to Kalaran Windblade to turn in [QT3441 Divine Retribution].
Talk to Lanie Reed to get the flight point.[G37.9,30.9,2Searing Gorge][P]
Fly to [F Refuge Pointe].
Use the Scroll of Myzrael at Shards of Myzrael and defeat the Princess to complete [QC656 Summoning the Princess].[G62.51,33.79,2Arathi Highlands]. You'll need a group for this. If you can't find one either drop the quest or come back later when you have one.
Click Shards of Myzrael to turn in [QT656 Summoning the Princess].
[G31,65,3Arathi Highlands][G21.5,75.4,3Arathi Highlands][G32.3,81.4,2Arathi Highlands]Talk to Shakes O'Breen to turn in [QT670 Sunken Treasure]. Accept [QA667 Death from Below].
Protect Shakes O'Breen to complete [QC667 Death From Below].
Talk to Shakes O'Breen to turn in [QT667 Death From Below].
Go to The Hinterlands.[G88.2,48.1,3Hillsbrad Foothills][G86,30.3,3Hillsbrad Foothills]
]], 'Caines Alliance Guides')