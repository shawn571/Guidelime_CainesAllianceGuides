Guidelime.registerGuide([[
[GA Alliance][N28-29Duskwood][NX29-29Ashenvale]
Talk to Commander Althea Ebonlocke to turn in [QT57 The Night Watch] and accept [QA58 The Night Watch].
Talk to Tavernkeep Smitts to turn in [QT156 Gather Rot Blossoms] and accept [QA159 Juice Delivery].
Talk to Innkeeper Trelayne to make this inn your home.[G73.9,44.4,2Duskwood][S]
Talk to Watcher Backus to turn in [QT1243 The Missing Diplomat] and accept [QA1244 The Missing Diplomat].
Kill Nightbane Dark Runners for [QC221 Worgen in the Woods].
Talk to Calor to turn in [QT221 Worgen in the Woods] and accept [QA222 Worgen in the Woods].
Fly to [F Sentinel Hill].
Go back to Duskwood and talk to Sven Yorgen to turn in [QT325 Armed and Ready].[G64.0,41.9,4Westfall][G7.8,34.1,2Duskwood]
Click A Weathered Grave to accept [QA225 The Weathered Grave].
Talk to Abercrombie to turn in [QT159 Juice Delivery] and accept [QA133 Ghoulish Effigy].
Kill various ghouls and loot them for [QC133 Ghoulish Effigy] and [QC101 The Totem of Infliction] and Plague Spreaders specifically for [QC58 The Night Watch].
Talk to Abercrombie to turn in [QT133 Ghoulish Effigy] and accept [QA134 Ogre Thieves].
Click the Defias Strongbox to complete [QC1244 The Missing Diplomat].
Click Abercrombie's Crate to complete [QC134 Ogre Thieves].
Talk to Abercrombie to turn in [QT134 Ogre Thieves] and accept [QA160 Note to the Mayor].
Grind until you are [XP29-15830 15830 XP from level 29].
Hearth to Darkshire.[H]
Talk to Commander Althea Ebonlocke to turn in [QT58 The Night Watch].
Talk to Sirra Von'Indi to turn in [QT225 The Weathered Grave] and accept [QA227 Morgan Ladimore].
Talk to Lord Ello Ebonlocke to turn in [QT160 Note to the Mayor] and accept [QA251 Translate Abercrombie's Note].
Talk to Sirra Von'Indi to turn in [QT251 Translate Abercrombie's Note] and accept [QA401 Wait for Sirra to Finish].
Talk to Sirra Von'Indi to turn in [QT401 Wait for Sirra to Finish] and accept [QA252 Translation to Ello].
Talk to Lord Ello Ebonlocke to turn in [QT252 Translation to Ello] and accept [QA253 Bride of the Embalmer].
Talk to Commander Althea Ebonlocke to turn in [QT227 Morgan Ladimore].
OPTIONAL ELITE - Talk to Commander Althea Ebonlocke to accept [QA228 Mor'Ladim].
Talk to Madame Eva to turn in [QT101 The Totem of Infliction].
Talk to Watcher Backus to turn in [QT1244 The Missing Diplomat] and accept [QA1245 The Missing Diplomat].
Fly to [F Stormwind].
Talk to High Sorcerer Andromath to turn in [QT1938 Ur's Treatise on Shadow Magic] and accept [QA1940 Pristine Spider Silk].[A Mage]
Talk to Elling Trias to turn in [QT1245 The Missing Diplomat] and accept [QA1246 The Missing Diplomat].
Talk to Dashel Stonefist to turn in [QT1246 The Missing Diplomat] and accept [QA1447 The Missing Diplomat].
Defeat Dashel Stonefist for [QC1447 The Missing Diplomat].
Talk to Dashel Stonefist to turn in [QT1447 The Missing Diplomat] and accept [QA1247 The Missing Diplomat].
Talk to Elling Trias to turn in [QT1247 The Missing Diplomat] and accept [QA1248 The Missing Diplomat].
Fly to [F Ironforge].
Talk to High Priest Rohan to accept [QA5675 Elune's Grace][G27.0,7.3,2Ironforge][A NightElf,Priest]
Talk to High Priest Rohan to accept and turn in [QA5641 A Lack of Fear][QT5641 A Lack of Fear].[G27.0,7.3,2Ironforge][A Dwarf,Priest]
Click the Waterlogged Envelope that you picked up a while ago in your bag to accept [QA637 Sully Balloo's Letter].
Talk to Sara Balloo to turn in [QT637 Sully Balloo's Letter] and accept [QA683 Sara Balloo's Plea].
Reach level [XP29].
#Put a point in Sharpened Claws.[A Druid]
#Put a point in Ferocity.[A Hunter]
#Put a point in Improved Psychic Scream.[A Priest]
#Put a point in Arctic Reach.[A Mage]
#Put a point in Deflection.[A Paladin]
#Put a point in Precision.[A Rogue]
#Put a point in Fel Concentration.[A Warlock]
#Put a point in Two-Handed Weapon Specialization.[A Warrior]
Talk to Tinkmaster Overspark to turn in [QT2923 Tinkmaster Overspark].
Talk to King Magni Bronzebeard to turn in [QT683 Sara Balloo's Plea] and accept [QA686 A King's Tribute].
Talk to Grand Mason Marblesten to turn in [QT686 A King's Tribute] and accept [QA689 A King's Tribute].
Fly to [F Menethil Harbor].
Talk to Mikhail to turn in [QT1248 The Missing Diplomat].
Talk to Innkeeper Helbrek to make this inn your home.[S][G10.7,60.9,2Wetlands]
Talk to Captain Stoutfist to turn in [QT474 Defeat Nek'rosh].
Take the boat to Auberdine.[G4.6,57.1,2Wetlands]
Fly to [F Astranaar].
]], 'Caines Alliance Guides')