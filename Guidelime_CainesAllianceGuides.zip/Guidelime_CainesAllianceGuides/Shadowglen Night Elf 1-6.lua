Guidelime.registerGuide([[
[GA Alliance][N1-6Shadowglen][NX6-12Teldrassil]
Talk to Conservator Ilthalaine to accept [QA456 The Balance of Nature].
Kill Young Nightsabers and Young Thistle Boars for [QC456 The Balance of Nature].
Reach level [XP2].
Talk to Dirania Silvershine to accept [QA4495 A Good Friend].
Talk to Melithar Staghelm to accept [QA458 The Woodland Protector].
Talk to Keina to vendor unneeded items.[G59.31,41.1,1Teldrassil][V]
Talk to Conservator Ilthalaine to turn in [QT456 The Balance of Nature] and accept [QA457 The Balance of Nature].
Talk to Conservator Ilthalaine to accept [QA3118 Encrypted Sigil][A Rogue].
Talk to Conservator Ilthalaine to accept [QA3117 Etched Sigil][A Hunter].
Talk to Conservator Ilthalaine to accept [QA3119 Hallowed Sigil][A Priest].
Talk to Conservator Ilthalaine to accept [QA3116 Simple Sigil][A Warrior].
Talk to Conservator Ilthalaine to accept [QA3120 Verdant Sigil][A Druid].
Talk to Frahun Shadewhisper to turn in [QT3118 Encrypted Sigil][A Rogue].
Talk to Ayanna Everstride to turn in [QT3117 Etched Sigil][A Hunter].
Talk to Shanda to turn in [QT3119 Hallowed Sigil][A Priest].
Talk to Alyissia to turn in [QT3116 Simple Sigil][A Warrior].
Talk to Mardant Strongoak to turn in [QT3120 Verdant Sigil][A Druid].
Talk to Tarindrella to turn in [QT458 The Woodland Protector] and accept [QA459 The Woodland Protector].
Kill Grell enemies and loot them for [QC459 The Woodland Protector].
Reach level [XP3].
Talk to Tarindrella to turn in [QT459 The Woodland Protector].
Talk to Gilshalan Windwalker to accept [QA916 Webwood Venom].
On the way to do the next steps kill Mangy Nightsabers and Thistle Boars for [QC457 The Balance of Nature][O] and Webwood Spiders for [QC916 Webwood Venom][O].
Talk to Iverron to turn in [QT4495 A Good Friend] and accept [QA3519 A Friend in Need].
Finish killing Mangy Nightsabers and Thistle Boars for [QC457 The Balance of Nature].
Reach level [XP4]
Talk to Dirania Silvershine to turn in [QT3519 A Friend in Need] and accept [QA3521 Iverron's Antidote].
Talk to Conservator Ilthalaine to turn in [QT457 The Balance of Nature].
Get Moonpetal Lilies for [QC3521,2 Iverron's Antidote].
Get Hyacinth Mushrooms for [QC3521,1 Iverron's Antidote].
Kill Webwood Spiders for [QC3521,3 Iverron's Antidote] and to finish [QC916 Webwood Venom].
Talk to Gilshalan Windwalker to turn in [QT916 Webwood Venom] and accept [QA917 Webwood Egg].
Reach level [XP5].
Talk to Dirania Silvershine to turn in [QT3521 Iverron's Antidote] and accept [QA3522 Iverron's Antidote].
Talk to Iverron to turn in [QT3522 Iverron's Antidote].
Go into the cave to the Webwood Egg.[G56.8,31.7Teldrassil][G57,28Teldrassil][G56.7,27Teldrassil]
Click Webwood Eggs to complete [QC917 Webwood Egg].
Die on purpose and resurrect at the spirit healer.
Talk to Gilshalan Windwalker to turn in [QT917 Webwood Egg]. Accept [QA920 Tenaron's Summons].
Talk to Tenaron Stormgrip to turn in [QT920 Tenaron's Summons] and accept [QA921 Crown of the Earth].
Use the Crystal Phial in your bag in the moonwell to complete [QC921 Crown of the Earth].[G59.93,33.03,1Teldrassil]
Grind until you are [XP6-340 340 XP until level 6].[G59,32.77Teldrassil]
Die on purpose and resurrect at the spirit healer.
Talk to Tenaron Stonegrip to turn in [QT921 Crown of the Earth] and accept [QA928 Crown of the Earth].
Reach level [XP6].
Talk to Shanda to accept [QA5622 In Favor of Elune].
Talk to Porthannius to accept [QA2159 Dolanaar Delivery].
]], 'Caines Alliance Guides')