Guidelime.registerGuide([[
[GA Alliance][N49-49Feralas and Tanaris][NX49-50Blasted Lands]
Talk to Pratt McGrubben to accept [QA7733 Improved Quality].
Talk to Troyas Moonbreeze to turn in [QT2943 Return to Troyas] and accept [QA2879 The Stave of Equinex].
Kill Cursed Sycamore for [QC51 Sweet Amber]. It wanders so you may have to look for it.
Kill Rage Scar Yetis for [QC7733 Improved Quality].
When Pristine Yeti Hide drops, use it in your bag to accept [QA7735 Pristine Yeti Hide].
Talk to Rockbiter to accept [QA2844 The Giant Guardian].
Use the Flame of Byltan, Flame of Lahassa, Flame of Imbal, Flame of Samha at these locations.[G38.5,15.8,2Feralas][G37.7,12.2,2Feralas][G39.9,9.4,2Feralas][G40.5,12.7,2Feralas].
Use Troya's Stave in your bag here. Then click the Equinex Monolith to turn in [QT2879 The Stave of Equinex] and accept [QA2942 The Morrow Stone]. [G38.88,13.14,2Feralas]
Talk to Shay Leafrunner to turn in [QT2844 The Giant Guardian] and accept [QA2845 Wandering Shay].
Click Shay's Chest to get Shay's Bell and escort her to safety. Use the bell whenever she get's distracted. Mark this step complete once you have the bell.
Talk to Rockbiter to turn in [QT2845 Wandering Shay].
Talk to Pratt McGrubben to turn in [QT7733 Improved Quality] and [QT7735 Pristine Yeti Hide].
Talk to Troyas Moonbreeze to turn in [QT2942 The Morrow Stone]
Fly to [F Gadgetzan].
Talk to Marin Noggenfogger to accept [QA2605 The Thirsty Goblin].
Talk to Tran'rek to accept [QA3362 Thistleshrub Valley].
Kill Thistleshrub Dew Collector for [QC2605 The Thirsty Goblin].
Kill Thistleshrub enemies for [QC3362 Thistleshrub Valley].
Talk to Tooga to accept [QA1560 Tooga's Quest].
Talk to Marvon Rivetseeker to turn in [QT3444 The Stone Circle] and accept [QA3446 Into the Depths].
Accept [QA3447 Secret of the Circle].
Complete [QC1560 Tooga's Quest][G66.6,25.7Tanaris].
Talk to Torta to turn in [QT1560 Tooga's Quest].
Talk to Marin Noggenfogger to turn in [QT2605 The Thirsty Goblin] and accept [QA2606 In Good Taste].
Talk to Tran'rek to turn in [QT3362 Thistleshrub Valley].
Talk to Sprinkle to turn in [QT2606 In Good Taste] and accept [QA2641 Sprinkle's Secret Ingredient].
Hearth to Stormwind[H].
Fly to [F Sentinel Hill].
Talk to Grimbooze Thunderbrew to turn in [QT51 Sweet Amber].
Fly to [F Nethergarde Keep].
]], 'Caines Alliance Guides')