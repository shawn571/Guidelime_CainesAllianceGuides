Guidelime.registerGuide([[
[GA Alliance][N1-5Northshire][NX5-12Elwynn Forest to Loch Modan]
Talk to Deputy Willem to accept [QA783 A Threat Within].
Talk to Marshal McBride to turn in [QT783 A Threat Within] and accept [QA7 Kobold Camp Cleanup].
Talk to Deputy Willem to accept [QA5261 Eagan Peltskinner].
Talk to Eagan Peltskinner to turn in [QT5261 Eagan Peltskinner] and accept [QA33 Wolves Across the Border].
Kill wolves and Kobold Vermin to complete [QC33 Wolves Across the Border] and [QC7 Kobold Camp Cleanup].
Reach level [XP2].
Talk to Eagan Peltskinner to turn in [QT33 Wolves Across the Border].
Reach level [XP3].
Sell unneeded items at Brother Danil.[G47.6,41.6,1Elwynn Forest]. Do this every time you return to this area.
Talk to Deputy Willem to accept [QA18 Brotherhood of Thieves].
Talk to Marshal McBride to turn in [QT7 Kobold Camp Cleanup] and accept [QA15 Investigate Echo Ridge].
Talk to Marshal McBride to accept [QA3101 Consecrated Letter].[A Paladin]
Talk to Marshal McBride to accept [QA3102 Encrypted Letter].[A Rogue]
Talk to Marshal McBride to accept [QA3104 Glyphic Letter].[A Mage]
Talk to Marshal McBride to accept [QA3103 Hallowed Letter].[A Priest]
Talk to Marshal McBride to accept [QA3100 Simple Letter].[A Warrior]
Talk to Marshal McBride to accept [QA3105 Tainted Letter].[A Warlock]
Talk to Brother Sammuel to turn in [QT3101 Consecrated Letter].[A Paladin]
Talk to Jorik Kerridan to turn in [QT3102 Encrypted Letter].[A Rogue]
Talk to Khelden Bremen to turn in [QT3104 Glyphic Letter].[A Mage]
Talk to Priestess Anetta to turn in [QT3103 Hallowed Letter].[A Priest]
Talk to Llane Beshere to turn in [QT3100 Simple Letter].[A Warrior]
Talk to Drusilla La Salle to turn in [QT3105 Tainted Letter] and accept [QA1598 The Stolen Tome].[A Warlock]
Kill Kobold Workers for [QC15 Investigate Echo Ridge].
Talk to Marshal McBride to turn in [QT15 Investigate Echo Ridge] and accept [QA21 Skirmish at Echo Ridge].
Go into the mine and kill Kobold Laborers for [QC21 Skirmish at Echo Ridge].
Reach level [XP4].
Click Stolen Books for [QC1598 The Stolen Tome].[A Warlock]
Kill Defias Thugs and loot them for [QC18 Brotherhood of Thieves].
Talk to Drusilla La Salle to turn in [QT1598 The Stolen Tome].[A Warlock]
Talk to Deputy Willem to turn in [QT18 Brotherhood of Thieves] and accept [QA6 Bounty on Garrick Padfoot] and [QA3903 Milly Osworth].
Talk to Marshal McBride to turn in [QT21 Skirmish at Echo Ridge] and accept [QA54 Report to Goldshire].
Reach level [XP5]
Sell unneeded items at Brother Danil.[G47.6,41.6,1Elwynn Forest]
Talk to Priestess Anetta to accept [QA5623 In Favor of the Light].[A Priest]
Talk to Milly Osworth to turn in [QT3903 Milly Osworth] and accept [QA3904 Milly's Harvest].
Kill Garrick Padfoot and loot him to complete [QC6 Bounty on Garrick Padfoot].
Click Milly's Harvest to complete [QC3904 Milly's Harvest].
Talk to Milly Osworth to turn in [QT3904 Milly's Harvest] and accept [QA3905 Grape Manifest].
Talk to Deputy Willem to turn in [QT6 Bounty on Garrick Padfoot].
Talk to Brother Neals to turn in [QT3905 Grape Manifest].
Talk to Falkhaan Isenstrider to accept [QA2158 Rest and Relaxation].
Die and resurrect at the spirit healer.[G45,50Elwynn Forest]
]], 'Caines Alliance Guides')