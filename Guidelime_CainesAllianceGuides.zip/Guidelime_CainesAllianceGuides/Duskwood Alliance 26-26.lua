Guidelime.registerGuide([[
[GA Alliance][N26-26Duskwood][NX26-28Wetlands]
Talk to Calor to accept [QA173 Worgen in the Woods].
Talk to Innkeeper Trelayne and make this inn your home.[S][G73.9,44.4,2Duskwood]
Talk to Tavernkeep Smitts to turn in [QT78 The Legend of Stalvan] and accept [QA79 The Legend of Stalvan].
Talk to Commander Althea Ebonlocke to turn in [QT79 The Legend of Stalvan] and accept [QA80 The Legend of Stalvan].
Talk to Clerk Daltry to turn in [QT80 The Legend of Stalvan] and accept [QA97 The Legend of Stalvan].
Talk to Councilman Millstipe to turn in [QT377 Crime and Punishment].
Talk to Commander Althea Ebonlocke to turn in [QT97 The Legend of Stalvan] and accept [QA98 The Legend of Stalvan].
Kill Nightbane Shadow Weavers for [QC173 Worgen in the Woods].
Click Mound of loose dirt to turn in [QT95 Sven's Revenge] and accept [QA230 Sven's Camp].
Finish killing spiders for [QC101,2 The Totem of Infliction].[G33,40Duskwood]
Talk to Abercrombie to turn in [QT157 Deliver the Thread] and accept [QA158 Zombie Juice].
While doing the next steps kill ghouls for [QC101,1 The Totem of Infliction][O]
Talk to Sven Yorgen to turn in [QT230 Sven's Camp] and accept [QA262 The Shadowy Figure].
Hearth to Darkshire.[H]
Talk to Tavernkeep Smitts to turn in [QT158 Zombie Juice] and accept [QA156 Gather Rot Blossoms].
Talk to Madame Eva to turn in [QT262 The Shadowy Figure] and accept [QA265 The Shadowy Search Continues].
Talk to Calor to turn in [QT173 Worgen in the Woods] and accept [QA221 Worgen in the Woods].
Talk to Clerk Daltry to turn in [QT265 The Shadowy Search Continues] and accept [QA266 Inquire at the Inn].
Talk to Tavernkeep Smitts to turn in [QT266 Inquire at the Inn] and accept [QA453 Finding the Shadowy Figure].
Talk to Jitters to turn in [QT240 Return to Jitters] and [QT453 Finding the Shadowy Figure]. Accept [QA268 Return to Sven].
Kill skeletons around here for [QC156 Gather Rot Blossoms], [QC57 The Night Watch], [QC101,3 The Totem of Infliction][G20,47Duskwood]
Kill skeletons for [QC2746,1 Items of Some Consequence] if you have the quest.[G20,47Duskwood]
Talk to Sven Yorgen to turn in [QT268 Return to Sven] and accept [QA323 Proving Your Worth].
Kill Skeletal Raiders, Healers and Warders for [QC323 Proving Your Worth].
Talk to Sven Yorgen to turn in [QT323 Proving Your Worth] and accept [QA269 Seeking Wisdom].
You will need 80 Lockpicking by this point. Go to Westfall to talk to Agent Kearnen to turn in [QT2360 Mathias and the Defias] and accept [QA2359 Klaven's Tower].[A Rogue]
Pickpocket the Malformed Defias Drone to steal the Defias Tower Key for [QC2359,2 Klaven's Tower].[A Rogue]
Make your way to the top of the tower, sap the elite, then open Duskwood Chest to complete [QC2359,1 Klaven's Tower].[A Rogue]
Go to Elwynn Forest and get Clara's Fresh Apples on the table in the hut for [QC2746,2 Items of Some Consequence]. You can die and resurrect at the spirit healer to get there quicker if you want.[G34.0,57.2,3Elwynn Forest]
Go to Stormwind and talk to Innkeeper Allison to make this inn your home.[S][G52.6,65.7,2Stormwind City]
Talk to Bishop Farthing to turn in [QT269 Seeking Wisdom] and accept [QA270 The Doomed Fleet].
Talk to Tyrion to turn in [QT2746 Items of Some Consequence].
Talk to Master Mathias Shaw to turn in [QT2359 Klaven's Tower].[A Rogue]
Fly to [F Menethil Harbor].
]], 'Caines Alliance Guides')