Guidelime.registerGuide([[
[GA Alliance][N56-57Blasted Lands][NX57-57Burning Steppes and Winterspring]
Talk to Fallen Hero of the Horde to accept [QA2681 The Stones That Bind Us].
Free Servants of Grol for [QC2681,2 The Stones That Bind Us].
Free Servants of Sevine for [QC2681,4 The Stones That Bind Us].
Free Servants of Razelikh for [QC2681,1 The Stones That Bind Us].
Free Servants of Allistarj for [QC2681,3 The Stones That Bind Us].
Talk to Fallen Hero of the Horde to turn in [QT2681 The Stones That Bind Us] and accept [QA2702 Heroes of Old].
Talk to Corporal Thund Splithoof to turn in [QT2702 Heroes of Old] and accept [QA2701 Heroes of Old].
Click Spectral Lockbox to turn in [QT2701 Heroes of Old].
OPTIONAL ELITE - Talk to Fallen Hero of the Horde to accept [QA2721 Kirith].
Kill Kirith the Damned for [QC2721 Kirith].
Talk to Spirit of Kirith to turn in [QT2721 Kirith] and accept [QA2743 The Cover of Darkness].[G65,34Blasted Lands]
Talk to Fallen Hero of the Horde to trun in [QT2743 The Cover of Darkness] and accept [QA2744 The Demon Hunter].
Reach level [XP57].
#Put a point in Improved Shred.[A Druid]
#Put a point in Mortal Shots.[A Hunter]
#Put a point in Improved Mind Blast.[A Priest]
#Put a point in Arcane Meditation.[A Mage]
#Put a point in Improved Blessing of Might.[A Paladin]
#Put a point in Lethality.[A Rogue]
#Put a point in Improved Curse of Agony.[A Warlock]
#Put a point in Enrage.[A Warrior]
Fly to [F Lakeshire].
Talk to Magistrate Solomon to turn in [QT4186 The True Masters] and accept [QA4223 The True Masters].
Fly to [F Morgan's Vigil].
]], 'Caines Alliance Guides')