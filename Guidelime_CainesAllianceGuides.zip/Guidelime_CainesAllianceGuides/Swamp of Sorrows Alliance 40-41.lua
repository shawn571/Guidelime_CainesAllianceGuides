Guidelime.registerGuide([[
[GA Alliance][N40-41 Swamp of Sorrows][NX41-42 Tanaris and Feralas]
Talk to Watcher Biggs to accept [QA1396 Encroaching Wildlife].
[G33.3,67.9Swamp of Sorrows][G52.3,9.3Blasted Lands][G66.5,21.4,2Blasted Lands]Go to Blasted Lands and talk to Quartermaster Lungertz to turn in [QT1395 Supplies for Nethergarde].
Talk to Alexandra Constantine to get the flight point.[G65.6,24.4,2Blasted Lands][F]
Kill Young Sawtooth Crocolisks, Sorrow Spinners and Swamp Jaguars for [QC1396 Encroaching Wildlife][O] while doing the next steps.
Kill whelps for [QC1116 Dream Dust in the Swamp].[G14,64Swamp of Sorrows]
Kill Noboru the Cudgel and loot Noboru's Cudgel. Click it in your bag to accept [QA1392 Noboru the Cudgel].[G47.1,38.9,3Swamp of Sorrows]
Finish up [QC1396 Encroaching Wildlife].
Talk to Watcher Biggs to turn in [QT1396 Encroaching Wildlife] and pick up [QA1421 The Lost Caravan].
Talk to Magtoor to turn in [QT1392 Noboru the Cudgel] and accept [QA1389 Draenethyst Crystals].
Talk to Anchorite Avuun and accept [QA9448 Mercy for the Cursed]
Reach level [XP41].
Click Draenethyst Crystals for [QC1389 Draenethyst Crystals].
Kill Cursed Lost Ones for [QC9448 Mercy for the Cursed].
Click Caravan Chest for [QC1421 The Lost Caravan].
Talk to Galen Goodward to accept [QA1393 Galen's Escape].
Escort Galen Goodward to safety to complete [QC1393 Galen's Escape].
Talk to Magtoor to turn in [QT1389 Draenethyst Crystals].
Talk to Holaaru to accept [QA9610 Pool of Tears]
Talk to Anchorite Avuun to turn in [QT9448 Mercy for the Cursed]
Talk to Watcher Biggs to turn in [QT1421 The Lost Caravan] and accept [QA1398 Driftwood].
Click Galen's Strongbox to turn in [QT1393 Galen's Escape].
Go here to complete [QC1448 In Search of the Temple].[G68,48Swamp of Sorrows]
Swim underwater and pick up Atal'ai Artifacts for [QC9610 Pool of Tears]
Pick up Sundried Driftwood for [QC1398 Driftwood][OC] while doing the next step.
Kill Silt Crawlers for [QC1258 ... and Bugs].
Finish up [QC1398 Driftwood].
Talk to Holaaru to turn in [QT9610 Pool of Tears]
Talk to Watcher Biggs to turn in [QT1398 Driftwood] and accept [QA1425 Deliver the Shipment].
Talk to Quartermaster Lungertz to turn in [QT1425 Deliver the Shipment].
Hearth to Booty Bay[H].
Talk to Crank Fizzlebub to turn in [QT600 Venture Company Mining].
Talk to First Mate Crazz to turn in [QT597 The Bloodsail Buccaneers] and accept [QA599 The Bloodsail Buccaneers].
Talk to Drizzlik to turn in [QT628 Excelsior].
Talk to Deeg to accept [QA587 Up to Snuff].
Talk to Krazek to turn in [QT1116 Dream Dust in the Swamp]. Accept [QA1117 Rumors for Kravel] and [QA2864 Tran'rek].
Talk to Kebok to turn in [QT209 Skullsplitter Tusks].
Talk to Fleet Master Seahorn to turn in [QT599 The Bloodsail Buccaneers]. Accept [QA604 The Bloodsail Buccaneers] and [QA670 Sunken Treasure].
Talk to Baron Revilgaz to turn in [QT601 Water Elementals] and accept [QA602 Magical Analysis].
Talk to "Shaky" Philipe to turn in [QT606 Scaring Shaky] and accept [QA607 Return to MacKinley].
Talk to "Sea Wolf" MacKinley to turn in [QT607 Return to MacKinley]. Accept [QA2872 Stoley's Debt].
[G25.9,73.1,3Stranglethorn Vale]Take the boat to Ratchet.
Fly to [F Theramore].
Talk to Morgan Stern to turn in [QT1258 ... and Bugs].
Talk to Lady Jaina Proudmoore to turn in [QT11223 Return to Jaina]
Fly to [F Mudsprocket]
Click Gizmorium Shipping Crate to complete [QC1187 Razzeric's Tweaking].[A Druid,Hunter,Priest,Rogue,Warlock,Warrior,Paladin,Shaman]
Talk to Tabetha to turn in [QT2861 Tabetha's Task].[A Mage]
Talk to Tabetha to turn in [QT2861 Tabetha's Task].[A Druid,Hunter,Priest,Rogue,Warlock,Warrior,Paladin,Shaman]
Fly to [F Gadgetzan].
]], 'Caines Alliance Guides')