Guidelime.registerGuide([[
[GA Alliance][N30-31Wetlands][NX31-32Hillsbrad Foothills]
Take the boat to Theramore.[A Warlock]
Fly to [F Ratchet].[A Warlock]
Talk to Strahad Farsan to turn in [QT1798 Seeking Strahad] and accept [QA1758 Tome of the Cabal].[A Warlock]
Fly to [F Theramore].[A Warlock]
Take the boat to Menethil Harbor.[A Warlock]
Talk to Vincent Hyal to turn in [QT1301 James Hyal] and accept [QA1302 James Hyal].
Talk to Rhag Garmason to accept [QA631 The Thandol Span].
Talk to Longbraid the Grim to accept [QA304 A Grim Task]. 
Talk to Motley Garmason to accept [QA303 The Dark Iron War].
[G51.4,8.1,3Wetlands][G51.3,8.3,3Wetlands][G51.3,8.0,2Wetlands]Click Ebenezer Rustlocke's Corpse to turn in [QT631 The Thandol Span] and accept [QA632 The Thandol Span].
Talk to Rhag Garmason to turn in [QT632 The Thandol Span] and accept [QA633 The Thandol Span].
[G46.1,88.1,3Arathi Highlands][G48.8,88.0,2Arathi Highlands]Click the Cache of Explosives to complete [QC633 The Thandol Span].
[G45.4,95.1,3Arathi Highlands][G49.9,18.2,2Wetlands]Talk to Rhag Garmason to turn in [QT633 The Thandol Span] and accept [QA634 Plea to the Alliance].
Kill Balgaras the Foul for [QC304 A Grim Task].
Kill Dark Iron enemies for [QC303 The Dark Iron War].
Talk to Motley Garmason to turn in [QT303 The Dark Iron War]. Skip the last quest - it is for Stockades which you out-level now and it's out of the way to come back here to turn in.
Talk to Longbraid the Grim to turn in [QT304 A Grim Task].
Reach level [XP31].
Go to Arathi Highlands.[G51.1,11.7,3Wetlands]
]], 'Caines Alliance Guides')