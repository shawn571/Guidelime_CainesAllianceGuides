Guidelime.registerGuide([[
[GA Alliance][N36-36Hillsbrad Foothills][NX36-37Stranglethorn Vale]
Talk to Marshal Redpath to accept [QA500 Crushridge Bounty].
Talk to Magistrate Henry Maleb to accept [QA505 Syndicate Assassins].
Talk to Phin Odelic to accept [QA659 Hints of a New Plague?].
Talk to Raleigh the Devout to turn in [QT1052 Down the Scarlet Path].
OPTIONAL SCARLET MONASTARY QUEST - Talk to Raleigh the Devout to accept [QA1053 In the Name of the Light].
OPTIONAL ELITE - Talk to Loremaster Dibbs to accept [QA540 Preserving Knowledge].
Talk to Darren Malvew to accept [QA564 Costly Menace].
Kill Mountain Lions and Hulking Mountain Lions for [QC564 Costly Menace].
Kill Syndicate Footpads and Thieves for [QC505 Syndicate Assassins].
Click Syndicate Documents to accept [QA510 Foreboding Plans].
Click Syndicate Documents to accept [QA511 Encrypted Letter].
Talk to Bath'rah the Windwatcher to turn in [QT1791 The Windwatcher]. Continue with this line if you want the Whirlwind Axe.[A Warrior]
Kill Crushridge enemies for [QC500 Crushridge Bounty] and [QC540,1 Preserving Knowledge].
Click the Weathered Bookcase for [QC540,2 Preserving Knowledge].
Either die here and resurrect at the spirit healer or run back to Southshore.
Talk to Darren Malvew to turn in [QT564 Costly Menace].
Talk to Loremaster Dibbs to turn in [QT511 Encrypted Letter] and [QT540 Preserving Knowledge]. Accept [QA514 Letter to Stormpike] and [QA542 Return to Milton].
Talk to Marshal Redpath to turn in [QT500 Crushridge Bounty].
Talk to Magistrate Henry Maleb to turn in [QT505 Syndicate Assassins] and [QT510 Foreboding Plans].
Hearth or fly to [F Ironforge].
Talk to Prospector Stormpike to turn in [QT514 Letter to Stormpike] and accept [QA525 Further Mysteries].
OPTIONAL SCARLET MONASTARY QUEST - Talk to Librarian Mae Paledust to accept [QA1050 Mythology of the Titans].
Fly to [F Stormwind].
Talk to Milton Sheaf to turn in [QT542 Return to Milton].
Buy a Moonsteel Broadsword from the auction house, or you can skip if you want.
Talk to Angus Stern to accept [QA1260 Morgan Stern].
Fly to [F Rebel Camp]
]], 'Caines Alliance Guides')